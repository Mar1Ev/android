package com.example.kr;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ProgressBar;
import android.widget.TextView;

public class MainActivity3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        TextView otv = (TextView) findViewById(R.id.otvet2) ;
        String otvet1 = getIntent().getStringExtra("otvet1");
        otv.setText(otvet1);
    }
}