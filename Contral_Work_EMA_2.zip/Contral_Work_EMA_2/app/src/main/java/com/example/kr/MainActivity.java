package com.example.kr;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    final String TAG = "States";
    TextView mTv;
    Button mBtn;
    DatePickerDialog dpd;
    ImageButton enter;
    Calendar c;

    EditText pyls3;
    EditText pyls6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageButton btn = findViewById(R.id.enter);
        btn.setOnClickListener(this);

        Spinner spinner1 = findViewById(R.id.spinner);

        mTv = (TextView)findViewById(R.id.year);
        mBtn = (Button)findViewById(R.id.date);
        pyls3 = (EditText)findViewById(R.id.pyls3);
        pyls6 = (EditText)findViewById(R.id.pyls6);
        enter = (ImageButton)findViewById(R.id.enter);

        mBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                c = Calendar.getInstance();
                int day;
                int month;
                int year;
                day = c.get(Calendar.DAY_OF_MONTH);
                month = c.get(Calendar.MONTH);
                year = c.get(Calendar.YEAR);
                dpd = new DatePickerDialog(MainActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int mYear, int mMonth, int mDay) {
                        mTv.setText(mDay + "/"+(mMonth + 1) + "/" + mYear);
                    }
                }, day, month, year);
                dpd.show();
            }
        });
    }


    private void sendPost(String[] params) throws Exception {

        String url = "http://abashin.ru/cgi-bin/ru/tests/burnout";
        URL obj = new URL(url);
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();
        con.setRequestMethod("POST");
        con.setRequestProperty("Accept-Language", "en-US,en;q=0.5");

        String urlParameters = "day="+params[0]+"&month="+params[1]+"&year="+params[2] +
                "&sex="+params[3]+"&m1="+params[4]+"&m2="+params[5];

        con.setDoOutput(true);
        DataOutputStream wr = new DataOutputStream(con.getOutputStream());
        wr.writeBytes(urlParameters);
        wr.flush();
        wr.close();

        BufferedReader in = new BufferedReader(
                new InputStreamReader(con.getInputStream()));
        String inputLine;
        StringBuffer response = new StringBuffer();
        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();
        String strResponse = response.toString();
        if (strResponse.contains("отсутствию переутомления")) {
            Intent results = new Intent(MainActivity.this, MainActivity2.class);
            String stroka1 = "Введенные значения соответствуют отсутствию переутомления.";
            results.putExtra("otvet1", stroka1);
            startActivity(results);
        } else if (strResponse.contains("небольшому переутомлению")) {
            Intent results = new Intent(MainActivity.this, MainActivity3.class);
            String stroka1 = "Введенные значения соответствуют небольшому переутомлению.";
            results.putExtra("otvet1", stroka1);
            startActivity(results);

        } else if (strResponse.contains("высокому уровню переутомления")) {
            Intent results = new Intent(MainActivity.this, MainActivity3.class);
            String stroka1 = "Введенные значения соответствуют значительному переутомлению.";
            results.putExtra("otvet1", stroka1);
            startActivity(results);

        } else {
            Intent results = new Intent(MainActivity.this, MainActivity4.class);
            startActivity(results);
        }
        System.out.println(response.toString());

    }

    public void onClick(View view) {
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {

                TextView calend = findViewById(R.id.year);
                String shar = calend.getText().toString();

                String[] parts = shar.split("/");
                String day = parts[0];
                String mon = parts[1];
                String yearr = parts[2];

                Log.v("zz", day);
                Log.v("zz", mon);
                Log.v("zz", yearr);


                Spinner pol = (Spinner)findViewById(R.id.spinner);


                String pol_1 = (String) pol.getSelectedItem();
                Log.v("zz", pol_1);

                if (pol_1 == "м"){
                    pol_1 = "1";
                } else {
                    pol_1 = "2";
                }
                EditText pyls_3 = (EditText)findViewById(R.id.pyls3);
                EditText pyls_6 = (EditText)findViewById(R.id.pyls6);
                String pyls3 = pyls_3.getText().toString();
                String pyls6 = pyls_6.getText().toString();
                Log.v("zz", pyls3);
                Log.v("zz", pyls6);

                String[] params = new String[] {day, mon, yearr, pol_1, pyls3, pyls6};
                try  {
                    sendPost(params);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        thread.start();
    }
}
